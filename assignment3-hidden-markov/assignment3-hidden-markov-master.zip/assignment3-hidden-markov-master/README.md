# assignment3-hidden-markov
assignment3-hidden-markov created by GitHub Classroom

# How to run

## Bigram

 ```sh   
    python bigram.py
```

## Trigram

```sh    
    python trigram.py
```

## Four-gram

```sh    
    python 4gram.py
```

### Parameters such as:

Add-k smooth model, or Linear Interpolation smooth model. 

Viterbi, or beam search.

beam width k.

Suboptimal sequences rate, correct prediction rate, and generating output.

### can be selected and modified in each file (in the commented out section).

